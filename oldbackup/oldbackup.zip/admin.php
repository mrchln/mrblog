﻿<?php
//前台入口
define('THINKPHP_PATH', './ThinkPHP/');//底层的位置
define('APP_PATH', './Admin/');//定义项目位置
define('APP_DEBUG', true);//定义DEBUG开关
require_once THINKPHP_PATH.'ThinkPHP.php';
//echo 'hellow';

?>