<?php
	namespace Home\Model;
	use Think\Model;
	class ArticleModel extends Model {
		return D('article');
	}

?>