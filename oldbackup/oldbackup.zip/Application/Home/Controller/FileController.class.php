<?php
namespace Home\Controller;
use Think\Controller;

class FileController extends Controller {

    public function index(){
        $fun=A('Fun');
        //$Mb=A('Data');
        //$Mb->isMobile();//检测终端
        $mood=M('mood');
        $skill=M('skill');
        $class=M('modular');
        $nav=M('navigation');
        $tag=M("tag");
        $selecttag=$tag->select();
        


        $selectmood=$mood->select();
        $selectskill=$skill->select();
        $updatemood=$mood->order("updatetime desc")->limit(2)->select();
        $updateskill=$skill->order("updatetime desc")->limit(2)->select();
        $moodreaded=$fun->count($mood);
        $skillreaded=$fun->count($skill);
        $count=$moodreaded+$skillreaded;
        //dump($count);
        $select=$nav->select();        
        $modular=$class->select();
        $arr_index=array(
            'navigation'=>$select,
            'modular'=>$modular,
            'selecttag'=>$selecttag,
            'fun'=>$fun,
            'mood'=>$mood,
            'skill'=>$skill,
            'tag'=>$tag,
            'count'=>$count,
            'selectmood'=>$selectmood,
            'selectskill'=>$selectskill,
            'moodcount'=>count($selectmood),
            'skillcount'=>count($selectskill),
            'updatemood'=>$updatemood,
            'updateskill'=>$updateskill,
            );

        $this->assign($arr_index);
        $this->display();
    }

    
    

}
?>