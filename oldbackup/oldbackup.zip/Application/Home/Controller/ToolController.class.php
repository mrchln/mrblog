<?php
namespace Home\Controller;
use Think\Controller;

class ToolController extends Controller {

	public function colorpicker(){
		$this->display();
	}
}