<?php
namespace Home\Controller;
use Think\Controller;
class MtController extends Controller {
    public function index(){

    	$friend=M("linju");
    	$user=M('article');
     	$friends=$friend->select();
        $locationArr=array(
            __APP__=>'当前位置：首页>心情文章',
            );
        //dump($locationArr);
        $this->assign('locationArr',$locationArr);
/*****************分页显示start*************************/
        $arr_page=$this->page($user,10);
        $show=$arr_page['show'];
        $Page=$arr_page['Page'];
        $article = $user->order('now desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        if(!empty($_POST['seach_classify'])){
            $seach_classify=$_POST['seach_classify'];
            $arr_page=$this->page($user,10,"classify='$seach_classify'");
            $show=$arr_page['show'];
            $Page=$arr_page['Page'];

            dump($Page->first);     
            $article=$user->order("now desc")->limit($Page->firstRow.','.$Page->listRows)->where("classify='$seach_classify'")->select();
        }
        //dump($list);
/*****************分页显示end************************/
        $arr_index=array(
            "friends"=>$friends,
            "friends_logo"=>$friends,
            "list"=>$article,
            "time"=>date('m,d',strtotime($article[0]['now'])),
            "page"=>$show,
            );
       // dump($article);
        $this->assign($arr_index);
        $this->assign('time',$arr_index);
    	$this->display();
    }
     public function center(){
        $user=M('article');
        $locationArr=array(
            __APP__=>'当前位置：首页>心情文章',
            );
        //dump($locationArr);
        $this->assign('locationArr',$locationArr);
/*****************分页显示start*************************/
        $arr_page=$this->page($user,10);
        $show=$arr_page['show'];
        $Page=$arr_page['Page'];
        $article = $user->order('now desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        if(!empty($_POST['seach_classify'])){
            $seach_classify=$_POST['seach_classify'];
            $arr_page=$this->page($user,10,"classify='$seach_classify'");
            $show=$arr_page['show'];
            $Page=$arr_page['Page'];

            dump($Page->first);     
            $article=$user->order("now desc")->limit($Page->firstRow.','.$Page->listRows)->where("classify='$seach_classify'")->select();
        }
        //dump($list);
/*****************分页显示end************************/
        $arr_index=array(
            "friends"=>$friends,
            "friends_logo"=>$friends,
            "list"=>$article,
            "time"=>date('m,d',strtotime($article[0]['now'])),
            "page"=>$show,
            );
       // dump($article);
        $this->assign($arr_index);
        $this->assign('time',$arr_index);
        $this->display();

     }
    public function page($db,$num,$where){
    	$count = $db->where($where)->count();// 
		$Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
		$show       = $Page->show();// 分页显示输出
		return $arr_page = array(
			"show"=>$show,
			"Page"=>$Page,
			"count"=>$count,
			);
		
    }
    public function detailed(){
        $locationArr=array(
            __CONTROLLER__=>'当前位置：首页>深度阅读',
            );
       // dump($locationArr);
        $this->assign('locationArr',$locationArr);
    	$user=M('article');
    	//print_r($_GET['id']);
    	if(!empty($_GET['id'])){
	    	$detailed=$user->where("id={$_GET['id']}")->select();
	    	//print_r($list);
	    	$before=$user->limit(1)->where("id>{$_GET['id']}")->select();
	    	//print_r($before);
	    	$after=$user->limit(1)->order('id desc')->where("id<{$_GET['id']}")->select();
	    	$user->where("id={$_GET['id']}")->setInc('readed',1);
	    	$arr_detailed=array(
	    		"list"=>$detailed,
	    		"before"=>$before,
	    		"after"=>$after,
	    		);
	    	$this->assign($arr_detailed);
  		}
    	$this->display();

    }
    
     public function about(){
        $locationArr=array(
            __CONTROLLER__=>'当前位置：首页>关于',
            );
       // dump($locationArr);
        $this->assign('locationArr',$locationArr);
     	$user=M("forme");
     	$about=$user->select();
     	//dump($about);
     	$this->assign("about",$about);
     	$this->display();
     }
     public function message(){
         $locationArr=array(
            __CONTROLLER__=>'当前位置：首页>留言',
            );
       // dump($locationArr);
        $this->assign('locationArr',$locationArr);
     	$this->display();
     }
     public function friends(){
     	$user=M("linju");
     	$friends=$user->select();
     	$this->assign("friends",$friends);
     	$this->display();
     }


}
