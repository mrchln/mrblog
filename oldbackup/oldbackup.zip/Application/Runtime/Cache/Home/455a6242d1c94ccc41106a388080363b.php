<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html>
<html lang="en">
<head>
	<meta property="qc:admins" content="14533242456523466375" />
	<meta charset="UTF-8">
	<meta name="keywords" content="陈礼宁的博客,陈小零博客,mrling小窝,小零博客" />
	<meta name="description" content="Mrling博客又名小零博客，分享心情记事，学习笔记的个人博客">
	

<title>超人不会飞 | MrLing</title>
<link rel="stylesheet" type="text/css" href="/Public/css/center.css" />
<link rel="stylesheet" type="text/css" href="/Public/css/head.css" />
<link rel="stylesheet" type="text/css" href="/Public/css/message.css" />
<script type="text/javascript" src="/Public/js/jquery171mini.js"></script>
<link rel="stylesheet" type="text/css" href="/Public/css/detailed.css" />
<link rel="shortcut icon" href="/Public/images/title.png">
<link rel="icon" type="image/gif" href="/Public/images/animated_favicon1.gif">
</head>
<body>
﻿
<div id="touxiangbox">
<a href="/index.php" title="回到首页"><div class="touxiang"></div></a>

</div>
<div class='head-message'>努力吧，至少可以离梦想近一些。
</div>

<div id="daohang_box">
<?php if(is_array($modular)): foreach($modular as $key=>$mod): ?><a href="/<?php echo ($mod['ename']); ?>"><div><?php echo ($mod['classify']); ?></div></a><?php endforeach; endif; ?>
<?php if(is_array($navigation)): $i = 0; $__LIST__ = $navigation;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$head): $mod = ($i % 2 );++$i;?><a href="/<?php echo ($head['ename']); ?>"><div><?php echo ($head['name']); ?></div></a><?php endforeach; endif; else: echo "" ;endif; ?>
</div>
<div></div>
<div id="Layer1" style="">    
 </div>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
<title>留言|MrLing</title>
<link rel="shortcut icon" href="images/title.png" />

</head>

<body>

<div id="message">
<!-- 留言内容   -->
<div id="message_box">
<div id="logo"></div>
    <div id="title">真挚的一句问候，我就能高兴一整天。</div>
   
   <!-- 多说评论框 start -->
	<div class="ds-thread" style="min-height:600px; margin-top:50px;" data-thread-key="-123" data-title="留言板" data-url="http://www.mrcln.com/message.html"></div>
<!-- 多说评论框 end -->
<!-- 多说公共JS代码 start (一个网页只需插入一次) -->
<script type="text/javascript">
var duoshuoQuery = {short_name:"mrling"};
	(function() {
		var ds = document.createElement('script');
		ds.type = 'text/javascript';ds.async = true;
		ds.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') + '//static.duoshuo.com/embed.js';
		ds.charset = 'UTF-8';
		(document.getElementsByTagName('head')[0] 
		 || document.getElementsByTagName('body')[0]).appendChild(ds);
	})();
	</script>
<!-- 多说公共JS代码 end --> 


 </div>
  <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
<title></title>
<link rel="stylesheet" type="text/css" href="/Public/css/footer.css" />
<link rel="stylesheet" type="text/css" href="/Public/css/bg.css" />
<script type="text/javascript" src="/Public/js/timeover.js"></script>
</head>

<body>
 <div class="Footer">
<div id="M_c">
 <div id="timebox">
<div id="nowTime"></div> 
</div>
<div id="copy">Copyright &copy;2014 Power By MrLing <a href="http://mrcln.com">mrcln.com</a> <script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Fbd0e4dff3b61b7c40da7910c165d6370' type='text/javascript'%3E%3C/script%3E"));
</script>
</div>

</div>

</div>

</body>
</html>
 </div>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
<title></title>
<link rel="stylesheet" type="text/css" href="/Public/css/gotop.css" />
</head>
<body>
<div class="actGotop"><a href="javascript:;" title="返回顶部">Top↑</a></div>
<script type="text/javascript">
$(function(){	
	$(window).scroll(function() {		
		if($(window).scrollTop() >= 400){
			$('.actGotop').fadeIn(300); 
		}else{    
			$('.actGotop').fadeOut(300);    
		}  
	});
	$('.actGotop').click(function(){
	$('html,body').animate({scrollTop: '0px'}, 800);});	
});
</script>

</body>
</html>
<!--BAIDU_YUNTU_START-->
<script>
(function(d, t) {
    var r = d.createElement(t), s = d.getElementsByTagName(t)[0];
    r.async = 1;
    r.src = '//rp.baidu.com/rp3w/3w.js?sid=5809846554303049806&t=' + Math.ceil(new Date/3600000);
    s.parentNode.insertBefore(r, s);
})(document, 'script');
</script>
<!--BAIDU_YUNTU_END-->
<script type="text/javascript" src="/Public/js/mrling.js"></script>
<script type="text/javascript" src="/Public/js/jquery.lazyload.js"></script>

</body>
</html>