<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html>
<html lang="en">
<head>
	<meta property="qc:admins" content="14533242456523466375" />
	<meta charset="UTF-8">
	<meta name="keywords" content="陈礼宁的博客,陈小零博客,mrling小窝,小零博客" />
	<meta name="description" content="Mrling博客又名小零博客，分享心情记事，学习笔记的个人博客">
	

<title>超人不会飞 | MrLing</title>
<link rel="stylesheet" type="text/css" href="/oldbackup/Public/css/center.css" />
<link rel="stylesheet" type="text/css" href="/oldbackup/Public/css/head.css" />
<link rel="stylesheet" type="text/css" href="/oldbackup/Public/css/message.css" />
<script type="text/javascript" src="/oldbackup/Public/js/jquery171mini.js"></script>
<link rel="stylesheet" type="text/css" href="/oldbackup/Public/css/detailed.css" />
<link rel="shortcut icon" href="/oldbackup/Public/images/title.png">
<link rel="icon" type="image/gif" href="/oldbackup/Public/images/animated_favicon1.gif">
</head>
<body>
﻿
<div id="touxiangbox">
<a href="/oldbackup/index.php" title="回到首页"><div class="touxiang"></div></a>

</div>
<div class='head-message'>努力吧，至少可以离梦想近一些。
</div>

<div id="daohang_box">
<?php if(is_array($modular)): foreach($modular as $key=>$mod): ?><a href="/oldbackup/<?php echo ($mod['ename']); ?>"><div><?php echo ($mod['classify']); ?></div></a><?php endforeach; endif; ?>
<?php if(is_array($navigation)): $i = 0; $__LIST__ = $navigation;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$head): $mod = ($i % 2 );++$i;?><a href="/oldbackup/<?php echo ($head['ename']); ?>"><div><?php echo ($head['name']); ?></div></a><?php endforeach; endif; else: echo "" ;endif; ?>
</div>
<div></div>
<div id="Layer1" style="">    
 </div>


<title>时光荏苒 | MrLing</title>
<script type="text/javascript" src="/oldbackup/Public/js/mrling.js"></script>
<script type="text/javascript">
   $(function(){
    textcut();
 })
</script>
<div id="container">
    <div id="container_box">
        <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div id="center_centent">
                
                <div id="author_time" >
                <div class="pancel">
                <div class="title"> <a id="title_a" href="/oldbackup/<?php echo CONTROLLER_NAME; ?>/<?php echo ($vo["id"]); ?>"><?php echo ($vo["title"]); ?></a></div>
                <span class='author'><?php echo ($vo["author"]); ?></span>
                <span class='time'><?php echo (date("Y,m,d",strtotime($vo["now"]))); ?></span>
                <span class="ds-thread-count" data-thread-key="<?php echo ($vo["id"]); ?>" data-count-type="comments" ></span>
                <span class='readed'>阅读：(<?php echo ($vo["readed"]); ?>)</span>
                </div>
                <!-- 多说js加载开始，一个页面只需要加载一次 -->
                <script type="text/javascript">
var duoshuoQuery = {short_name:"mrling"};
(function() {
    var ds = document.createElement('script');
    ds.type = 'text/javascript';ds.async = true;
    ds.src = 'http://static.duoshuo.com/embed.js';
    ds.charset = 'UTF-8';
    (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(ds);
})();
</script>
                <!-- 多说js加载结束，一个页面只需要加载一次 -->
                
                <hr/>
                <div class="box">
                    <div id="content_index">
                     <?php echo (html_entity_decode($vo["content"])); ?>
                    </div>
                </div>
                
            </div>
            
            </div><?php endforeach; endif; else: echo "" ;endif; ?>
        <div class="fenye"><?php echo ($page); ?></div>
    </div>
    <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
<title></title>
<link rel="stylesheet" type="text/css" href="/oldbackup/Public/css/footer.css" />
<link rel="stylesheet" type="text/css" href="/oldbackup/Public/css/bg.css" />
<script type="text/javascript" src="/oldbackup/Public/js/timeover.js"></script>
</head>

<body>
 <div class="Footer">
<div id="M_c">
 <div id="timebox">
<div id="nowTime"></div> 
</div>
<div id="copy">Copyright &copy;2014 Power By MrLing <a href="http://mrcln.com">mrcln.com</a> <script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Fbd0e4dff3b61b7c40da7910c165d6370' type='text/javascript'%3E%3C/script%3E"));
</script>
</div>

</div>

</div>

</body>
</html>
</div>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
<title></title>
<link rel="stylesheet" type="text/css" href="/oldbackup/Public/css/gotop.css" />
</head>
<body>
<div class="actGotop"><a href="javascript:;" title="返回顶部">Top↑</a></div>
<script type="text/javascript">
$(function(){	
	$(window).scroll(function() {		
		if($(window).scrollTop() >= 400){
			$('.actGotop').fadeIn(300); 
		}else{    
			$('.actGotop').fadeOut(300);    
		}  
	});
	$('.actGotop').click(function(){
	$('html,body').animate({scrollTop: '0px'}, 800);});	
});
</script>

</body>
</html>
<!--BAIDU_YUNTU_START-->
<script>
(function(d, t) {
    var r = d.createElement(t), s = d.getElementsByTagName(t)[0];
    r.async = 1;
    r.src = '//rp.baidu.com/rp3w/3w.js?sid=5809846554303049806&t=' + Math.ceil(new Date/3600000);
    s.parentNode.insertBefore(r, s);
})(document, 'script');
</script>
<!--BAIDU_YUNTU_END-->
<script type="text/javascript" src="/oldbackup/Public/js/mrling.js"></script>
<script type="text/javascript" src="/oldbackup/Public/js/jquery.lazyload.js"></script>

</body>
</html>