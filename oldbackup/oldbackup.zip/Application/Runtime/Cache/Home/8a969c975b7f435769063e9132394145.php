<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html>
<html lang="en">
<head>
	<meta property="qc:admins" content="14533242456523466375" />
	<meta charset="UTF-8">
	<meta name="keywords" content="陈礼宁的博客,陈小零博客,mrling小窝,小零博客" />
	<meta name="description" content="Mrling博客又名小零博客，分享心情记事，学习笔记的个人博客">
	

<title>超人不会飞 | MrLing</title>
<link rel="stylesheet" type="text/css" href="/Public/css/center.css" />
<link rel="stylesheet" type="text/css" href="/Public/css/head.css" />
<link rel="stylesheet" type="text/css" href="/Public/css/message.css" />
<script type="text/javascript" src="/Public/js/jquery171mini.js"></script>
<link rel="stylesheet" type="text/css" href="/Public/css/detailed.css" />
<link rel="shortcut icon" href="/Public/images/title.png">
<link rel="icon" type="image/gif" href="/Public/images/animated_favicon1.gif">
</head>
<body>
﻿
<div id="touxiangbox">
<a href="/index.php" title="回到首页"><div class="touxiang"></div></a>

</div>
<div class='head-message'>努力吧，至少可以离梦想近一些。
</div>

<div id="daohang_box">
<?php if(is_array($modular)): foreach($modular as $key=>$mod): ?><a href="/<?php echo ($mod['ename']); ?>"><div><?php echo ($mod['classify']); ?></div></a><?php endforeach; endif; ?>
<?php if(is_array($navigation)): $i = 0; $__LIST__ = $navigation;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$head): $mod = ($i % 2 );++$i;?><a href="/<?php echo ($head['ename']); ?>"><div><?php echo ($head['name']); ?></div></a><?php endforeach; endif; else: echo "" ;endif; ?>
</div>
<div></div>
<div id="Layer1" style="">    
 </div>


<link rel="stylesheet" type="text/css" href="/Public/css/friends.css" />
<div id="message">
<div id="message_box">
<div id="logo-neighbors"></div>
<div id="title">心灵的秋海棠，万年常青</div>
<div class="box">
<fieldset>  
<legend>友好邻居</legend>
<span class="lj">  
<?php if(is_array($friends)): foreach($friends as $key=>$fs): ?><a href="javascript:window.open('<?php echo ($fs["link"]); ?>')" title="<?php echo ($fs["message"]); ?>"><?php echo ($fs["nearly"]); ?></a><?php endforeach; endif; ?>
</span>
</fieldset>
</div>
<div class="box">
<fieldset> 
<legend>图片链</legend>
<span class="lj">
<?php if(is_array($friends)): foreach($friends as $key=>$fs): ?><a href="javascript:window.open('<?php echo ($fs["link"]); ?>')" title="<?php echo ($fs["message"]); ?>"><img src="<?php echo ($fs["logo"]); ?>" /></a><?php endforeach; endif; ?>
</span>
</fieldset>
</div>

<div id="linju_require">
<div class="box">
<fieldset> 
<legend>邻居说明</legend>
<ol>
<li>1.博客内容健康，且无广告</li>
<li>2.能正常访问</li>
<li>3.域名长期使用，尽量不更改</li>
<li>4.下方评论申请，申请格式：站点名称+域名+邮箱</li>
<li>本站信息：小零博客</li>
<li>网站地址：http://mrcln.com</li>
<li>网站Logo：http://mrcln.com/images/logo.gif</li>
<li><a href="http://mrcln.com"><img src="/Public/images/logo.gif" width="88" height="31" /></a></li>
</ol>
</fieldset>
</div>
</div>

<div id="ds">
 <!-- 多说评论框 start -->
	<div class="ds-thread" data-thread-key="-100" data-title="邻居" data-url="http://mrcln.com/neighbors"></div>
<!-- 多说评论框 end -->
<!-- 多说公共JS代码 start (一个网页只需插入一次) -->
<script type="text/javascript">
var duoshuoQuery = {short_name:"mrling"};
	(function() {
		var ds = document.createElement('script');
		ds.type = 'text/javascript';ds.async = true;
		ds.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') + '//static.duoshuo.com/embed.js';
		ds.charset = 'UTF-8';
		(document.getElementsByTagName('head')[0] 
		 || document.getElementsByTagName('body')[0]).appendChild(ds);
	})();
	</script>
<!-- 多说公共JS代码 end -->
</div>
</div>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
<title></title>
<link rel="stylesheet" type="text/css" href="/Public/css/footer.css" />
<link rel="stylesheet" type="text/css" href="/Public/css/bg.css" />
<script type="text/javascript" src="/Public/js/timeover.js"></script>
</head>

<body>
 <div class="Footer">
<div id="M_c">
 <div id="timebox">
<div id="nowTime"></div> 
</div>
<div id="copy">Copyright &copy;2014 Power By MrLing <a href="http://mrcln.com">mrcln.com</a> <script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Fbd0e4dff3b61b7c40da7910c165d6370' type='text/javascript'%3E%3C/script%3E"));
</script>
</div>

</div>

</div>

</body>
</html>
</div>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
<title></title>
<link rel="stylesheet" type="text/css" href="/Public/css/gotop.css" />
</head>
<body>
<div class="actGotop"><a href="javascript:;" title="返回顶部">Top↑</a></div>
<script type="text/javascript">
$(function(){	
	$(window).scroll(function() {		
		if($(window).scrollTop() >= 400){
			$('.actGotop').fadeIn(300); 
		}else{    
			$('.actGotop').fadeOut(300);    
		}  
	});
	$('.actGotop').click(function(){
	$('html,body').animate({scrollTop: '0px'}, 800);});	
});
</script>

</body>
</html>
<!--BAIDU_YUNTU_START-->
<script>
(function(d, t) {
    var r = d.createElement(t), s = d.getElementsByTagName(t)[0];
    r.async = 1;
    r.src = '//rp.baidu.com/rp3w/3w.js?sid=5809846554303049806&t=' + Math.ceil(new Date/3600000);
    s.parentNode.insertBefore(r, s);
})(document, 'script');
</script>
<!--BAIDU_YUNTU_END-->
<script type="text/javascript" src="/Public/js/mrling.js"></script>
<script type="text/javascript" src="/Public/js/jquery.lazyload.js"></script>

</body>
</html>