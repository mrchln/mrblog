<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>时间之轴 | MrLing</title>
<link rel="stylesheet" type="text/css" href="/Public/timeaxis/css/history.css">
<script type="text/javascript" src="/Public/timeaxis/js/jquery.js"></script>
<script type="text/javascript" src="/Public/timeaxis/js/jquery.mousewheel.js"></script>
<script type="text/javascript" src="/Public/timeaxis/js/jquery.easing.js"></script>
<script type="text/javascript" src="/Public/timeaxis/js/history.js"></script>

</head>
<body>

<div id="arrow">
	<ul>
		<li class="arrowup"></li>
		<li class="arrowdown"></li>
	</ul>
</div>

<div id="history">

	<div class="title">
		<h2>博客历程</h2>
		<div id="circle">
			<div class="cmsk"></div>
			<div class="circlecontent" title="返回首页">
				<div thisyear="2014" class="timeblock" >
					<span class="numf"></span>
					<span class="nums"></span>
					<span class="numt"></span>
					<span class="numfo"></span>
					<div class="clear"></div>
				</div>
				<div class="timeyear">YEAR</div>
			</div>
			<a href="" class="clock"></a>
		</div>
	</div>
	
	<div id="content">
		<ul class="list">
		<?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
			
				<div class="liwrap">
					<div class="lileft">
						<div class="date">
							<span class="year"><?php echo (date("Y",strtotime($vo["time"]))); ?></span>
							<span class="md"><?php echo (date("m,d",strtotime($vo["time"]))); ?></span>
						</div>
					</div>
					
					<div class="point"><b></b></div>
					
					<div class="liright">
						<div class="histt"><a href="#"><?php echo ($vo['title']); ?></a></div>
						<div class="hisct"><?php echo ($vo['content']); ?></div>
					</div>
				</div>
			
			</li><?php endforeach; endif; else: echo "" ;endif; ?>
			
		</ul>
	</div>
</div>

</body>
</html>